package upload;

import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/video")
@MultipartConfig(maxFileSize = 73400329)
public class Video extends HttpServlet {
	private static final long serialVersionUID = 1L;
 

	private String dbURL = "jdbc:mysql://localhost:3306/appdb";
	private String dbUser = "root";
	private String dbPass = "123";
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.setContentType("");
	
		Connection  con=null;
        Statement stmt=null;
         String sql="";
		PrintWriter writer=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		
		
		InputStream vbytes = null;
		Part video=request.getPart("video");
		String id1=request.getParameter("id");
		
		int id2=Integer.parseInt(id1);
		
		try {
			if(!video.getContentType().equals("video/mp4"))
			{
				   writer.println("<br/> Invalid File");
                 return;
			}else if(video.getSize()>73400329 )  //2mb
			{
				  writer.println("<br/> File size too big");
	              return;
			}
			
			vbytes=video.getInputStream();  //to get body
			
			byte[] bytes=new byte[vbytes.available()];  //storing binaray data into bytes array
			
			vbytes.read(bytes);     //read 
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		
		///Checking connection
		try {
			 DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			 con = DriverManager.getConnection(dbURL, dbUser, dbPass);
			 
			 int success=0;
           PreparedStatement pstmt = con.prepareStatement("insert into video values(?,?)");
           pstmt.setInt(1, id2);
           pstmt.setBlob(2, vbytes);   //Storing binary data in blob field.
           success = pstmt.executeUpdate();
           if(success>=1)  System.out.println("video Stored");
            con.close(); 

            writer.println("<br/> Video Successfully Stored");
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
}
}
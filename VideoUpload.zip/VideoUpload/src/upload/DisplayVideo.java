package upload;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayVideo
 */
@WebServlet("/DisplayVideo")
public class DisplayVideo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		private String dbURL = "jdbc:mysql://localhost:3306/appdb";
		private String dbUser = "root";
		private String dbPass = "123";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		  Blob image = null;
	      Connection con = null;
	      Statement stmt = null;
	      ResultSet rs = null;
	      ServletOutputStream out = response.getOutputStream();
	      
	      try {
	    	  DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			  con = DriverManager.getConnection(dbURL, dbUser, dbPass);
			  stmt = con.createStatement();
		      rs = stmt.executeQuery("select video from video where id ='2'");
		      if (rs.next()) {
		      image = rs.getBlob(1);

		      }else {
		          response.setContentType("video/mp4");

		          out.println("<font color='red'>image not found for given id</font>");
		          return;
		      }
		      
		      response.setContentType("video/mp4"); 
		      //response.setContentType("video/mp4");
		  
		      InputStream in = image.getBinaryStream();
		       int length = (int) image.length();
		       int bufferSize = 1024;
		       byte[] buffer = new byte[bufferSize];
		       while ((length = in.read(buffer)) != -1) {
		       out.write(buffer, 0, length);
		       }
		       in.close();
		       out.flush();
	    	  
		} catch (Exception e) {
			// TODO: handle exception
			
			response.setContentType("text/html");
			  out.println("<html><head><title>Unable To Display image</title></head>");
			  out.println("<body><h4><font color='red'>Image Display Error=" + e.getMessage() +
			   "</font></h4></body></html>");
			  return;
		}
	      finally {
	    	  
	    	  try {
			
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	}
}
